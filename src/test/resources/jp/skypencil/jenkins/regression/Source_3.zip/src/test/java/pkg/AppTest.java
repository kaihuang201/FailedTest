package pkg;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AppTest {
	@Test
	public void testApp1() {
		assertTrue(true);
	}

	@Test
	public void testApp2() {
		assertTrue(false);
	}

	@Test
	public void testApp3() {
		assertTrue(true);
	}
}
